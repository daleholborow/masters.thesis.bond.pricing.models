http://www.mngt.waikato.ac.nz/departments/staff/kurthess/frontpage/ModelMainpages/FixedIncomeModels.htm

Send mail to kurthess@waikato.ac.nz with questions or comments about this web site.
Copyright � 2008 Kurt Hess, University of Waikato
Last modified: 18-Apr-2008

Includes implementation of JP Morgan pricing methodology

