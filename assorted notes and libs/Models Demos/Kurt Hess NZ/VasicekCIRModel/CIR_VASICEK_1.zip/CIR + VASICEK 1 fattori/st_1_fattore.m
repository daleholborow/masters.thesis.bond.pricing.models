function varargout = st_1_fattore(varargin)
%%%%%%%%%% CIR & VASICECK 1FACTOR %%%%%%%%%%
%This routine was developed by Massimiliano Zanetti.
%It's free downlodable at www.quantitativefinance.co.uk
%Please, email the author (mzanetti@quantitative finance.co.uk)
%for any bug or suggested improvement.
%%%%%%%%%%%%%%%%%%%%%%%


gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @st_1_fattore_OpeningFcn, ...
                   'gui_OutputFcn',  @st_1_fattore_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

function st_1_fattore_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);
function varargout = st_1_fattore_OutputFcn(hObject, eventdata, handles)
varargout{1} = handles.output;

function edit1_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit1_Callback(hObject, eventdata, handles)

function edit2_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit2_Callback(hObject, eventdata, handles)

function edit3_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit3_Callback(hObject, eventdata, handles)

function edit4_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit4_Callback(hObject, eventdata, handles)

function edit5_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','yellow');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit5_Callback(hObject, eventdata, handles)

function edit6_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','yellow');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit6_Callback(hObject, eventdata, handles)

function edit7_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','yellow');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit7_Callback(hObject, eventdata, handles)

function edit8_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','yellow');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit8_Callback(hObject, eventdata, handles)

function edit9_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit9_Callback(hObject, eventdata, handles)

% --------- END OF GUI CODE ----------


function pushbutton4_Callback(hObject, eventdata, handles)

% --------- CARICO LA SERIE STORICA DEI DATI ----------

load dati.mat
axes(handles.axes1)
surf(tabtassi)

function pushbutton1_Callback(hObject, eventdata, handles)

 % --------- VASICEK MODEL USING ONE TERM ONLY ----------
 
global Y0 ka te si er;

%loading data
ka = str2double(get(handles.edit1,'String'));
te = str2double(get(handles.edit2,'String'));
si = str2double(get(handles.edit3,'String'));
er = str2double(get(handles.edit4,'String'));

load dati.mat
Y0 = tabtassi(10,:)';
x0 = [ka te si er];
lb = [0 0 0 0];

x = lsqnonlin('objf', x0, lb);

% data output
set(handles.edit5,'String',x(1))
set(handles.edit6,'String',x(2))
set(handles.edit7,'String',x(3))
set(handles.edit8,'String',x(4))

kappa = x(1);
teta = x(2);
sigma = x(3);
r = x(4);
lambda = 0;

% ATTENTION: the term structure is fixed in the code.
t=[0.25 0.5 0.75 1	2	3	4	5	6	7	8	9];
Y=[];

for i = 1:12
    b = (1-(exp(-kappa*t(1,i))))/kappa;
    a = exp((((b-t(1,i))*((kappa^2*teta)-(sigma^2/2)))/kappa^2)-((sigma^2*b^2)/(4*kappa)));
    Y(i,1) = ((-log(a))+(b*r))/t(1,i);
end

%graph
axes(handles.axes1)
plot(t, Y0);
hold on
plot(t, Y, 'red');
hold off
legend('Attuale', 'Stimata');

% ESTIMATION USING ALL TERMS
Ymat=[];
kappam=[];
tetam=[];
sigmam=[];

for j=1:80;
Y0 = tabtassi(j,:)';
x = lsqnonlin ('objf', x0);

kappa = x(1);
kappam(j,1) = kappa;
teta = x(2);
tetam(j,1) = teta;
sigma = x(3);
sigmam(j,1)=sigma;

r = x(4);
lambda = 0;

% ATTENTION: the term structure is fixed in the code.
t=[0.25 0.5 0.75 1	2	3	4	5	6	7	8	9];

for i = 1:12
    b = (1-(exp(-kappa*t(1,i))))/kappa;
    a = exp((((b-t(1,i))*((kappa^2*teta)-(sigma^2/2)))/kappa^2)-((sigma^2*b^2)/(4*kappa)));
    Ymat(j,i) = ((-log(a))+(b*r))/t(1,i);
end
end  

%SURFACE'S GRAPH
axes(handles.axes2)
surf(Ymat);

%KAPPA'S GRAPH
axes(handles.axes3)
plot(kappam);

%TETA' GRAPH
axes(handles.axes4)
plot(tetam);

%SIGMA'S GRAPH
axes(handles.axes5)
plot(sigmam);


% --------- FEND OF VASICEK  ----------


function pushbutton3_Callback(hObject, eventdata, handles)

 % --------- VASICEK MODEL USING ONE TERM ONLY ----------


ka = str2double(get(handles.edit1,'String'));
te = str2double(get(handles.edit2,'String'));
si = str2double(get(handles.edit3,'String'));
er = str2double(get(handles.edit4,'String'));

global Y0 ka te si er;
load dati
Y0 = tabtassi(10,:)';
x0 = [ka te si er];
lb = [0 0 0 0];

x = lsqnonlin ('objfcir', x0, lb);

set(handles.edit5,'String',x(1))
set(handles.edit6,'String',x(2))
set(handles.edit7,'String',x(3))
set(handles.edit8,'String',x(4))

kappa = x(1);
teta = x(2);
sigma = x(3);
r = x(4);
lambda = 0;
gamma = sqrt(((x(1) + 0)^2) + (2* (x(3))^2));
s = x(1) + 0 + gamma;


t=[0.25 0.5 0.75 1	2	3	4	5	6	7	8	9];
Y=[];

for i = 1:12
    a = ((2*gamma*(exp((s*t(1,i))/2)))/((s*(exp(gamma*t(1,i))-1))+(2*gamma)))^((2*kappa*teta)/(sigma^2));
    b = (2*(exp(gamma*t(1,i))-1))/((s*(exp(gamma*t(1,i))-1))+(2*gamma));
    Y(i,1) = ((-log(a))+(b*r))/t(1,i);
end


axes(handles.axes1)
plot(t, Y0);
hold on
plot(t, Y, 'red');
hold off
legend('Attuale', 'Stimata');

% CALCOLO STIMA SU TUTTE LE SCADENZE
Ymat2=[];
for j=1:80;
Y0 = tabtassi(j,:)';
x = lsqnonlin('objfcir', x0, lb);

kappa = x(1);
kappam(j,1) = kappa;
teta = x(2);
tetam(j,1) = teta;
sigma = x(3);
sigmam(j,1)=sigma;
r = x(4);
lambda = 0;
gamma = sqrt(((x(1) + 0)^2) + (2* (x(3))^2));
s = x(1) + 0 + gamma;


% ATTENTION: the term structure is fixed in the code.
t=[0.25 0.5 0.75 1	2	3	4	5	6	7	8	9];

for i = 1:12
    a = ((2*gamma*(exp((s*t(1,i))/2)))/((s*(exp(gamma*t(1,i))-1))+(2*gamma)))^((2*kappa*teta)/(sigma^2));
    b = (2*(exp(gamma*t(1,i))-1))/((s*(exp(gamma*t(1,i))-1))+(2*gamma));
    Ymat2(j,i) = ((-log(a))+(b*r))/t(1,i);
end
end  


axes(handles.axes2)
surf(Ymat2);

axes(handles.axes3)
plot(kappam);

axes(handles.axes4)
plot(tetam);

axes(handles.axes5)
plot(sigmam);