function f = objf(x)
global Y0;
load dati

kappa = x(1);
teta = x(2);
sigma = x(3);
r = x(4);

f=[];
t=[0.25 0.5 0.75 1	2	3	4	5	6	7	8	9];

for i = 1:12
  b = (1-(exp(-kappa*t(1,i))))/kappa;
  a = exp((((b-t(1,i))*((kappa^2*teta)-(sigma^2/2)))/kappa^2)-((sigma^2*b^2)/4*kappa));
  y = ((-log(a))+(b*r))/t(1,i);
  g = Y0(i,1)-y;
  f(i,1) = g;
end