function f = objfcir(x)
% funzione di ottimizzazione per il modello cir

global Y0 ka te si er
load dati

kappa = x(1);
teta = x(2);
sigma = x(3);
r = x(4);
lambda = 0;
gamma = sqrt(((x(1) + 0)^2) + (2* (x(3))^2));
s = x(1) + 0 + gamma;

f=[];
k=[0.25 0.5 0.75 1 2 3	4	5	6	7	8	9];

for i = 1:12
    a = ((2*gamma*(exp((s*k(1,i))/2)))/((s*(exp(gamma*k(1,i))-1))+(2*gamma)))^((2*kappa*teta)/(sigma^2));
    b = (2*(exp(gamma*k(1,i))-1))/((s*(exp(gamma*k(1,i))-1))+(2*gamma));
    y= ((-log(a))+(b*r))/k(1,i);
    g = Y0(i,1)-y;
    f(i,1) = g;
end