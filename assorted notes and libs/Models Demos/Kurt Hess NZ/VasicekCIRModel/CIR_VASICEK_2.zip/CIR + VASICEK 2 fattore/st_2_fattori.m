function varargout = st_2_fattori(varargin)
%%%%%%%%%% CIR & VASICECK 1FACTOR %%%%%%%%%%
%This routine was developed by Massimiliano Zanetti.
%It's free downlodable at www.quantitativefinance.co.uk
%Please, email the author (mzanetti@quantitative finance.co.uk)
%for any bug or suggested improvement.
%%%%%%%%%%%%%%%%%%%%%%%

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @st_2_fattori_OpeningFcn, ...
                   'gui_OutputFcn',  @st_2_fattori_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
function st_2_fattori_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);
function varargout = st_2_fattori_OutputFcn(hObject, eventdata, handles)
varargout{1} = handles.output;

function edit1_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit1_Callback(hObject, eventdata, handles)

function edit2_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit2_Callback(hObject, eventdata, handles)


function edit3_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit3_Callback(hObject, eventdata, handles)

function edit5_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit5_Callback(hObject, eventdata, handles)

function edit6_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit6_Callback(hObject, eventdata, handles)

function edit7_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit7_Callback(hObject, eventdata, handles)

function edit9_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','yellow');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit9_Callback(hObject, eventdata, handles)

function edit10_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','yellow');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit10_Callback(hObject, eventdata, handles)

function edit11_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','yellow');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit11_Callback(hObject, eventdata, handles)

function edit12_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','yellow');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit12_Callback(hObject, eventdata, handles)

function edit13_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','yellow');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit13_Callback(hObject, eventdata, handles)

function edit14_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','yellow');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
function edit14_Callback(hObject, eventdata, handles)



function pushbutton3_Callback(hObject, eventdata, handles)
% ---------- STARING POINT --------------
load dati.mat
axes(handles.axes1)
surf(tabtassi)

function pushbutton1_Callback(hObject, eventdata, handles)
% ---------- VASICEK WITH 2 FACTORS --------------
global Y0;
load dati.mat

Y0 = tabtassi(50,[1:11])';

ka1 = str2double(get(handles.edit1,'String'));
te1 = str2double(get(handles.edit2,'String'));
si1 = str2double(get(handles.edit3,'String'));
ka2 = str2double(get(handles.edit5,'String'));
te2 = str2double(get(handles.edit6,'String'));
si2 = str2double(get(handles.edit6,'String'));

x0 = [ka1 te1 si1 ka2 te2 si2];
lb = [0 0 0 0 0 0];
x = lsqnonlin ('objf2', x0);

y=[];

kappa = x(1);
teta = x(2);
sigma = x(3);
r1 = tabtassi(1,12);

kappa2 = x(4);
teta2 = x(5);
sigma2 = x(6);
r2 = (tabtassi(1,1)-tabtassi(1,12));


% ATTENTION: the term structure is fixed in the code.
t=[0.25 0.5 0.75 1	2	3	4	5	6	7	8];

set(handles.edit9,'String',x(1))
set(handles.edit10,'String',x(2))
set(handles.edit11,'String',x(3))
set(handles.edit12,'String',x(4))
set(handles.edit13,'String',x(5))
set(handles.edit14,'String',x(6))

for i = 1:11
  b1 = (1-(exp(-kappa*t(1,i))))/kappa;
  a1 = exp((((b1-t(1,i))*((kappa^2*teta)-(sigma^2/2)))/kappa^2)-((sigma^2*b1^2)/(4*kappa)));
  
  b2 = (1-(exp(-kappa2*t(1,i))))/kappa2;
  a2 = exp((((b2-t(1,i))*((kappa2^2*teta2)-(sigma2^2/2)))/kappa2^2)-((sigma2^2*b2^2)/(4*kappa2)));
  
  y(i,1) = ((-log(a1))+(b1*r1))/t(1,i)+((-log(a2))+(b2*r2))/t(1,i);
end

axes(handles.axes1)
title('Struttura stimata');
plot(t, Y0);
hold on
plot(t, y, 'red');
hold on
legend('Attuale', 'Stimata');


% ESTIMATING THE MODEL FOR THE ALL TERM STRUCTURE

global Y0;
load dati
Ymat=[];
kappam1=[];
tetam1=[];
sigmam1=[];
kappam2=[];
tetam2=[];
sigmam2=[];

for j=1:80;
Y0 = tabtassi(j,:)';
x = lsqnonlin ('objf2', x0);

kappa = x(1);
kappam1(j,1) = kappa;
teta = x(2);
tetam1(j,1) = teta;
sigma = x(3);
sigmam1(j,1)=sigma;
r1 = tabtassi(1,12);

kappa2 = x(4);
kappam2(j,1) = kappa2;
teta2 = x(5);
tetam2(j,1) = teta2;
sigma2 = x(6);
sigmam2(j,1)=sigma2;
r2 = (tabtassi(1,1)-tabtassi(1,12));

t=[0.25 0.5 0.75 1	2	3	4	5	6	7	8];

for i = 1:11
  b1 = (1-(exp(-kappa*t(1,i))))/kappa;
  a1 = exp((((b1-t(1,i))*((kappa^2*teta)-(sigma^2/2)))/kappa^2)-((sigma^2*b1^2)/(4*kappa)));
  
  b2 = (1-(exp(-kappa2*t(1,i))))/kappa2;
  a2 = exp((((b2-t(1,i))*((kappa2^2*teta2)-(sigma2^2/2)))/kappa2^2)-((sigma2^2*b2^2)/(4*kappa2)));
  
  Ymat(i,j) = ((-log(a1))+(b1*r1))/t(1,i)+((-log(a2))+(b2*r2))/t(1,i);
end
end 


axes(handles.axes2)
title('Valori stimati dal modello Vasicek');
surf(Ymat');


axes(handles.axes3)
plot(kappam1);
hold on;
plot(kappam2, 'red');
legend('K 1','K 2');
hold off;


axes(handles.axes6)
plot(tetam1);
hold on;
plot(tetam2, 'red');
legend('T 1','T 2');
hold off;


axes(handles.axes7)
plot(sigmam1);
hold on;
plot(sigmam2, 'red');
legend('S 1','S 2');
hold off;



% ------------------------- CIR MODEL WITH 2 FACTORS -------------

function pushbutton2_Callback(hObject, eventdata, handles)

global Y0;
load dati.mat

Y0 = tabtassi(3,[1:11])';


ka1 = str2double(get(handles.edit1,'String'));
te1 = str2double(get(handles.edit2,'String'));
si1 = str2double(get(handles.edit3,'String'));
ka2 = str2double(get(handles.edit5,'String'));
te2 = str2double(get(handles.edit6,'String'));
si2 = str2double(get(handles.edit6,'String'));

x0 = [ka1 te1 si1 ka2 te2 si2];
lb = [0 0 0 0 0 0];
x = lsqnonlin ('objf2cir', x0);

y=[];

kappa = x(1);
teta = x(2);
sigma = x(3);
r1 = tabtassi(1,12);
lambda = 0;
gamma = sqrt(((x(1) + 0)^2) + (2* (x(3))^2));
s = x(1) + 0 + gamma;

kappa2 = x(4);
teta2 = x(5);
sigma2 = x(6);
r2 = (tabtassi(1,1)-tabtassi(1,12));
lambda2 = 0;
gamma2 = sqrt(((x(4) + 0)^2) + (2* (x(6))^2));
s2 = x(4) + 0 + gamma;

% ATTENTION: the term structure is fixed in the code.
t=[0.25 0.5 0.75 1	2	3	4	5	6	7	8];


set(handles.edit9,'String',x(1))
set(handles.edit10,'String',x(2))
set(handles.edit11,'String',x(3))
set(handles.edit12,'String',x(4))
set(handles.edit13,'String',x(5))
set(handles.edit14,'String',x(6))


for i = 1:11
    a1 = ((2*gamma*(exp((s*t(1,i))/2)))/((s*(exp(gamma*t(1,i))-1))+(2*gamma)))^((2*kappa*teta)/(sigma^2));
    b1 = (2*(exp(gamma*t(1,i))-1))/((s*(exp(gamma*t(1,i))-1))+(2*gamma));
    
    a2 = ((2*gamma2*(exp((s2*t(1,i))/2)))/((s2*(exp(gamma2*t(1,i))-1))+(2*gamma2)))^((2*kappa2*teta2)/(sigma2^2));
    b2 = (2*(exp(gamma2*t(1,i))-1))/((s2*(exp(gamma2*t(1,i))-1))+(2*gamma2));
    
    
   y(i,1) = ((-log(a1))+(b1*r1))/t(1,i)+((-log(a2))+(b2*r2))/t(1,i);
end


axes(handles.axes1)
title('Struttura stimata');
plot(t, Y0);
hold on
plot(t, y, 'red');
hold on
legend('Attuale', 'Stimata');


% ESTIMATING THE MODEL FOR THE ALL TERM STRUCTURE

global Y0;
load dati
Ymat2=[];
kappam1=[];
tetam1=[];
sigmam1=[];
kappam2=[];
tetam2=[];
sigmam2=[];

for j=1:80;
Y0 = tabtassi(j,:)';
x = lsqnonlin ('objf2cir', x0);

kappa = x(1);
kappam1(j,1) = kappa;
teta = x(2);
tetam1(j,1) = teta;
sigma = x(3);
sigmam1(j,1)=sigma;
r1 = tabtassi(1,12);
lambda = 0;
gamma = sqrt(((x(1) + 0)^2) + (2* (x(3))^2));
s = x(1) + 0 + gamma;

kappa2 = x(4);
kappam2(j,1) = kappa2;
teta2 = x(5);
tetam2(j,1) = teta2;
sigma2 = x(6);
sigmam2(j,1)=sigma2;
r2 = (tabtassi(1,1)-tabtassi(1,12));
lambda2 = 0;
gamma2 = sqrt(((x(4) + 0)^2) + (2* (x(6))^2));
s2 = x(4) + 0 + gamma;

t=[0.25 0.5 0.75 1	2	3	4	5	6	7	8];

for i = 1:11
    a1 = ((2*gamma*(exp((s*t(1,i))/2)))/((s*(exp(gamma*t(1,i))-1))+(2*gamma)))^((2*kappa*teta)/(sigma^2));
    b1 = (2*(exp(gamma*t(1,i))-1))/((s*(exp(gamma*t(1,i))-1))+(2*gamma));
    
    a2 = ((2*gamma2*(exp((s2*t(1,i))/2)))/((s2*(exp(gamma2*t(1,i))-1))+(2*gamma2)))^((2*kappa2*teta2)/(sigma2^2));
    b2 = (2*(exp(gamma2*t(1,i))-1))/((s2*(exp(gamma2*t(1,i))-1))+(2*gamma2));
    
    Ymat2(j,i) = ((-log(a1))+(b1*r1))/t(1,i)+((-log(a2))+(b2*r2))/t(1,i);
end
end 


axes(handles.axes2)
title('Valori stimati dal modello CIR');
surf(Ymat2');


axes(handles.axes3)
plot(kappam1);
hold on;
plot(kappam2, 'red');
legend('K 1','K 2');
hold off;


axes(handles.axes6)
plot(tetam1);
hold on;
plot(tetam2, 'red');
legend('T 1','T 2');
hold off;


axes(handles.axes7)
plot(sigmam1);
hold on;
plot(sigmam2, 'red');
legend('S 1','S 2');
hold off;
