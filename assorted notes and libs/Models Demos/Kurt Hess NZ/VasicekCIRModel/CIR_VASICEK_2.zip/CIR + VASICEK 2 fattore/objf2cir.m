function f = objf2cir(x)
global Y0;
load dati

kappa = x(1);
teta = x(2);
sigma = x(3);
r1 = tabtassi(1,12);
lambda = 0;
gamma = sqrt(((x(1) + 0)^2) + (2* (x(3))^2));
s = x(1) + 0 + gamma;

kappa2 = x(4);
teta2 = x(5);
sigma2 = x(6);
r2 = (tabtassi(1,1)-tabtassi(1,12));
lambda2 = 0;
gamma2 = sqrt(((x(4) + 0)^2) + (2* (x(6))^2));
s2 = x(4) + 0 + gamma;

f=[];
k=[0.25 0.5 0.75 1	2	3	4	5	6	7	8];

for i = 1:11
  a1 = ((2*gamma*(exp((s*k(1,i))/2)))/((s*(exp(gamma*k(1,i))-1))+(2*gamma)))^((2*kappa*teta)/(sigma^2));
  b1 = (2*(exp(gamma*k(1,i))-1))/((s*(exp(gamma*k(1,i))-1))+(2*gamma));
  
  a2 = ((2*gamma2*(exp((s2*k(1,i))/2)))/((s2*(exp(gamma2*k(1,i))-1))+(2*gamma2)))^((2*kappa2*teta2)/(sigma2^2));
  b2 = (2*(exp(gamma2*k(1,i))-1))/((s2*(exp(gamma2*k(1,i))-1))+(2*gamma2));
    
  y = ((-log(a1))+(b1*r1))/k(1,i)+((-log(a2))+(b2*r2))/k(1,i);
  
  g = Y0(i,1)-y;
  f(i,1) = g;
end