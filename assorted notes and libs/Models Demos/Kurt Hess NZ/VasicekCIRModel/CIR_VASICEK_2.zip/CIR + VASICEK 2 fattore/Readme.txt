%%%%%%%%%% CAPM %%%%%%%%%%
%This routine was developed by Massimiliano Zanetti.
%It's free downlodable at www.quantitativefinance.co.uk
%Please, email the author (mzanetti@quantitative finance.co.uk)
%for any bug or suggested improvement.
%%%%%%%%%%%%%%%%%%%%%%%

1. the file dati.mat contains data useful for running the routine. It's composed by 2 tables:
	a: TABTASSI, it's the observed interest rate structure (monthly) for 12 period
	b: TABTASSI_g, it's the obseved intrest rate structure (daily) for 12 period


2. run st_2_fattori.m to start the Graphical User interfce

3. files objf2.m and objf2cir.m are called by the principal routine to run the optimization process.
   DO NOT DELETE THEM




