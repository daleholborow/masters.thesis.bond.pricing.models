function f = objf2(x)
global Y0;
load dati.mat

kappa = x(1);
teta = x(2);
sigma = x(3);
r1 = tabtassi(1,12);

kappa2 = x(4);
teta2 = x(5);
sigma2 = x(6);
r2 = (tabtassi(1,1)-tabtassi(1,12));

f=[];
t=[0.25 0.5 0.75 1	2	3	4	5	6	7	8];

for i = 1:11
  b1 = (1-(exp(-kappa*t(1,i))))/kappa;
  a1 = exp((((b1-t(1,i))*((kappa^2*teta)-(sigma^2/2)))/kappa^2)-((sigma^2*b1^2)/4*kappa));
  
  b2 = (1-(exp(-kappa2*t(1,i))))/kappa2;
  a2 = exp((((b2-t(1,i))*((kappa2^2*teta2)-(sigma2^2/2)))/kappa2^2)-((sigma2^2*b2^2)/4*kappa2));
  
  y = ((-log(a1))+(b1*r1))/t(1,i)+((-log(a2))+(b2*r2))/t(1,i);
  
  g = Y0(i,1)-y;
  f(i,1) = g;
end