function n = count(this)

% Retrieve the number of entries in the hashtable.

n = this.numel;