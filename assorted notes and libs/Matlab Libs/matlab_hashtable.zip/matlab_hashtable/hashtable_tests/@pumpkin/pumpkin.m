function this = pumpkin(val)

t.val = val;

this = class(t, 'pumpkin');
